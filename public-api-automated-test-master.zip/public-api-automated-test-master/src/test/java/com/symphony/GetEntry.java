package com.symphony;

import com.symphony.PublicApiEntries;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = PublicApiEntries.class)

public class GetEntry {

    @Value("${global.public.url}")
    private String url;

    @Test
    public void getPublicEntryRequest(){
        RestAssured.baseURI =url;
        given().
                contentType("application/json").
                when().
                get(GetEntries.getEntriesEndpoint()).
                then().
                log().ifError().
                assertThat().statusCode(200).and().contentType(ContentType.JSON)
                .and().
                body("count",equalTo(1425));
    }
}
