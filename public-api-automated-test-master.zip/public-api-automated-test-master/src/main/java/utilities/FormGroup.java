package utilities;

import java.util.HashMap;

public class FormGroup {
    HashMap<String,String> form = new HashMap<>();
}
