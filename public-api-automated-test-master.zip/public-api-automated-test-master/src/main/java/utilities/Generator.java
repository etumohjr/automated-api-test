package utilities;

import com.github.javafaker.Faker;

import java.util.Random;

/**
 * Generator Class is used to generate random names and numbers to be supplied while testing
 * */

public class Generator {

    private Random randValue  = new Random(System.nanoTime());
    private Faker fakerData = new Faker(randValue);

    /**
     * returns string of 11 random characters as phoneNum
     */
    public  String genPhoneNumber(){
        StringBuilder phoneNum = new StringBuilder();
        for (int i = 0;i<=10;i++){
            phoneNum.append(randValue.nextInt(9));
        }
        System.out.println(phoneNum.toString());
        return phoneNum.toString();
    }
    /**
     * returns string of 10 random characters as accNum
     */

    public String genAccountNumber(){
        StringBuilder accNum = new StringBuilder();
        for (int i = 0; i<=9;i++){
            accNum.append(randValue.nextInt(9));
        }
        System.out.println(accNum.toString());
        return accNum.toString();
    }
    /**
     * uses the fakerClass to return random names
     */
    public String genName(){
        return fakerData.name().firstName();
    }
}
