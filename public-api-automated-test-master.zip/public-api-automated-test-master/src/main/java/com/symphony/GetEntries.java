package com.symphony;

public class GetEntries {

    public static String getEntriesEndpoint(){
        String resource = "/entries";
        return resource;
    }
}
