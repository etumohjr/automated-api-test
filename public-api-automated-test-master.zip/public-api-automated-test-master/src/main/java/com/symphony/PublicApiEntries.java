package com.symphony;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class PublicApiEntries {

    public static void main(String[] args) {
        SpringApplication.run(PublicApiEntries.class, args);
    }
}
