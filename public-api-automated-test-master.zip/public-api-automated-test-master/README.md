# payment-api-automated-test
RestAssured API
